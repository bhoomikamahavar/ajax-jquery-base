<?php

/**
 *   BHOOMIKA
 * 
 *   New Code Learn & Add Here
 */

/**
 1)  Add inline CSS [ Already Exists Stylesheet ]
     #URL: : https://developer.wordpress.org/reference/functions/wp_add_inline_style/
*/

	/**
	 * Add color styling from theme
	 */
	function wpdocs_styles_method() {
		wp_enqueue_style(
			'custom-style',
			get_template_directory_uri() . '/css/custom_script.css'
		);
	        $color = get_theme_mod( 'my-custom-color' ); //E.g. #FF0000
	        $custom_css = "
	                .mycolor{
	                        background: {$color};
	                }";
	        wp_add_inline_style( 'custom-style', $custom_css );
	}
	add_action( 'wp_enqueue_scripts', 'wpdocs_styles_method' );

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 2)  Customize the contact information fields available to your WordPress users. Edits the available contact methods on a user’s profile page. Contact methods can be both added and removed.
     #URL: : https://developer.wordpress.org/reference/hooks/user_contactmethods/
*/

	add_filter( 'user_contactmethods', 'modify_user_contact_methods' );

	function modify_user_contact_methods( $methods ) {

	        // Add user contact methods
	        $methods['skype']   = __( 'Skype Username'   );
	        $methods['twitter'] = __( 'Twitter Username' );

	        // Remove user contact methods
	        unset( $methods['aim']    );
	        unset( $methods['jabber'] );

	        return $methods;
	}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 3)  Text Limiter Function
*/
	function tokopress_text_limiter($text, $limit = 25, $ending = '...') {
	        if ( strlen($text) > $limit ) {

	                $text = wp_strip_all_tags($text);
	                $text = substr($text, 0, $limit);
	                $text = substr($text, 0, -(strlen(strrchr($text, ' '))));
	                $text = $text . $ending;

	        }

	        return $text;
	}

	//Function Use like this :=

	<?php echo tokopress_text_limiter( get_the_excerpt(), 860 );

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
*  4) For THeme Custmization Save = Action
*/
	add_action( 'customize_save_after', 'tokopress_customize_save_after' );

	function tokopress_customize_save_after() {
		$output = tokopress_customize_output();
		set_theme_mod( 'tokopress_customize_css', $output['style'] );
		set_theme_mod( 'tokopress_customize_fonts', $output['fonts'] );
		set_theme_mod( 'tokopress_customize_saved', true );
	}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
*  5) How To Find WordPress Page ID By Title Then Replace the_content()
   URL : https://developer.wordpress.org/reference/functions/get_page_by_title/
*/
	function my_content($content) {
		$page = get_page_by_title( 'Sample Page' );
		if ( is_page($page->ID) )
			$content = "Hello World!";
		return $content;
	}
	add_filter('the_content', 'my_content');

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
 * 6) Remove a previously enqueued CSS stylesheet.
 * URL : https://developer.wordpress.org/reference/functions/wp_dequeue_style/
 */
	add_action( 'wp_enqueue_scripts', 'mywptheme_child_deregister_styles', 11 );
	function mywptheme_child_deregister_styles() {
		wp_dequeue_style( 'mywptheme' );

	}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 *  7) Check category are multiple insert into the deal listing  post type via cron
 * 	#URL = https://manawatunz.co.nz/
 * 
	https://manawatunz.co.nz/wp-admin/edit.php?post_type=deals
	https://manawatunz.co.nz/wp-admin/edit.php?post_type=listing
 
    This all Data is add by PostMan API
    #URL = https://www.postman.com/

 */

#OLD_CODE = START

	function insertListCategories($val, $dealCat = "deal_cat")
	{
		$parent_term = term_exists($val,$dealCat); // array is returned if taxonomy is given
		if (empty($parent_term)) {
			$parent_term = wp_insert_term(
				$val,    
				$dealCat, 
			);
		}
		return $parent_term;
	}

	function instertSubcategory($val, $dealCat = "deal_cat", $parent_id)
	{
		$parent_term = term_exists($val,$dealCat); // array is returned if taxonomy is given

		// $testing = $parent_term;
		
		if (empty($parent_term)) {
			$parent_term = wp_insert_term(
				$val,   // the term 
				$dealCat, // the taxonomy
				array(
					'parent' => $parent_id
				)
			);
		} else {
			wp_update_term(
				$parent_term,   // the term 
				$dealCat, // the taxonomy
				array(
					'parent' => $parent_id
				)
			);
		}
		return $parent_term;
	}


#OLD_CODE = END

============================

#REPPLACENEWCODE = START

	function insertListCategories($val, $dealCat = "deal_cat")
	{
		$parent_term = get_term_by( 'name', $val, $dealCat);
		if( empty($parent_term) ){
			
			$parent_term = wp_insert_term( 
							  $val, 
							  $dealCat,
							  array(
								'description' => 'Parent category',
							  )
							);
			return $parent_term;
		}
		return $parent_term->term_id;
	}



	function instertSubcategory( $val, $dealCat = "deal_cat", $parent_id ){
		$term_check = get_term_by( 'name', $val, $dealCat);
		
		if( empty($term_check)){
			$output_parent_term =   wp_insert_term( 
				$val, 
				$dealCat, 
				array(
					'description' => 'Sub-category',
					'parent' => $parent_id,
				)
			);
			return $output_parent_term;
		}
		return $term_check->term_id;;
	}

#REPPLACENEWCODE = END

// NOTE :    When you want to add parent term OR You want to add child term in Parent term then

//	         instead of this [ term_exists() == FALSE [ this is wrong ] ] ====== [ get_term_by() == TRUE [ Use this for check term ] ]  

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 *  8) FOR Remove Space and return value with proper slug use this function
 */

	function get_strip_all_tags($string, $remove_breaks = false)
	{
		$string = preg_replace('@<(script|style)[^>]*?>.*?</\\1>@si', '', $string);
		$string = strip_tags($string);
		if ($remove_breaks) {
			$string = preg_replace('/[\r\n\t ]+/', ' ', $string);
		}
		return trim($string);
	}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
  9)  In Example [ https://testing.local/wp-admin/edit.php?post_type=post ]

	+ With Fix Selected value and action like [ Trash post Alert AND ] = If YES Then [ Action Submit ] + Else [ Only Cancel ]

   #REF_URL [ MAIN ] : https://plnkr.co/edit/YTY7PDs5Uh1XGUo9ic1s?p=preview&preview

   #CSS = https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css
   #JS = https://unpkg.com/sweetalert/dist/sweetalert.min.js

   #HELPFUL = https://stackoverflow.com/questions/6799533/how-to-submit-a-form-with-javascript-by-clicking-a-link

*/

	'use strict' ?>

	<script>

	    document.querySelector('#bulk-action-selector-top').addEventListener('change', function(e) {
	    
	        var form = this;
	      
	        e.preventDefault();

	        let selectedvalue = this.value;

	        if( selectedvalue == 'trash' ){
	      
	            swal({
	              title: "Are you sure?",
	              text: 'It will temporary deleted in ' + selectedvalue.toUpperCase(),
	              icon: "warning",
	              buttons: [
	                'No, cancel it!',
	                'Yes, I am sure!'
	              ],
	              dangerMode: true,

	            }).then(function(isConfirm) {

	                  if (isConfirm) {

	                    swal({
	                      title: 'Trash!',
	                      text: 'Post is temporary deleted successfully !',
	                      icon: 'success'

	                    }).then(function() {

	                            var confirm_action = document.getElementById("posts-filter");

	                            confirm_action.submit();

	                            console.log("Yes");

	                    });

	                  } else {

	                    swal("Cancelled", "Your imaginary file is safe :)", "error");

	                  }

	            });

	        }

	    });

	</script>

<?php /*

I just change action like

OLD = First SweetAlert Shown first and then action submit OR Delete shown = This is wrong

So

NEW = When we will give change value of select option to TRASH == 

TRASH VALUE GET THEN LOOP IS START

===

IF TRASH THEN SHOWN

2 buttons 

Button 1) No 

  ACTION IS NORMAL EXIT

Button 2) Yes

	So, Here we will first do Action && ALso with this we will give Sweet Alert Notification for user so user can understand that action is in process...

NEW CHANGES START =======

*/ ?>

	<script type="text/javascript">

		swal({
			title: 'Trash!',
			text: 'Post is temporary deleted successfully !',
			icon: 'success'

		});

		var confirm_action = document.getElementById("posts-filter");

		confirm_action.submit();

	</script>

<?php /*

NEW CHANGES END =======

In Case [ If we hit button [ Cancel ] and then again click on [Confirm] Then issue happend of Loop So I give window.reload so loop continues ] CODE BELOW

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// ?>

	<script type="text/javascript">

		'use strict'

	    document.querySelector('#bulk-action-selector-top').addEventListener('change', function() {
	    
	        var form = this;

	        let selectedvalue = this.value;

	        if( selectedvalue == 'trash' ){
	      
	                swal({

	                    title: "Are you sure?",
	                    text: 'It will temporary deleted in ' + selectedvalue.toUpperCase(),
	                    icon: "warning",
	                    buttons: [
	                    'No, cancel it!',
	                    'Yes, I am sure!'
	                    ],
	                    dangerMode: true,

	                }).then(function(isConfirm) {

	                    if ( isConfirm ) {

	                        swal({
	                          title: 'Trash!',
	                          text: 'Post is temporary deleted successfully !',
	                          icon: 'success'

	                        });

	                        var confirm_action = document.getElementById("posts-filter");

	                        confirm_action.submit();

	                    }else {

	                        swal({
	                            title: 'Cancelled!',
	                            text: 'Your post is safe !',
	                            icon: 'error'
	                        });

	                        window.location.reload();

	                      }

	                });

	        }

	    });

	</script>

<?php /*

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

10) Getting values of multiple selected checkboxes

	+ In Admin [ https://testing.local/wp-admin/edit.php?post_type=product ]

	+ For Get Value of selected checkbox - Condition is for each And Also Multiple checkbox checked and get value

	+ REF URL : https://www.javascripttutorial.net/javascript-dom/javascript-checkbox/

*/ ?>

	<script type="text/javascript">

		const btn = document.querySelector('#bulk-action-selector-top');

		btn.addEventListener('change', (event) => {
		  
		    let checkboxes = document.querySelectorAll('input[name="post[]"]:checked');

		    let values = [];

		    checkboxes.forEach((checkbox) => {
		        values.push(checkbox.value);
		    });

		    alert(values);
		    
		}); 

	</script>


<?php /*

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

11) Getting current page url on wp-admin/admin dashboard?

#REF_URL = https://stackoverflow.com/questions/64828762/getting-current-page-url-on-wp-admin-admin-dashboard

Condition is The Slug is [ ?Page ]

And we want to add this script in this admin page

So we will first find 

1)  in admin url
    + admin_url()

2)  $GET["page"]
    + Page name get

[ full function to get current admin page with url is == admin_url( "admin.php?page=".$_GET["page"] ) ]

*/

	add_action( 'admin_enqueue_scripts', 'custom_script_marketica', 99 );

	function custom_script_marketica(){

		global $pagenow;

		$current_page = admin_url( "admin.php?page=".$_GET["page"] );

		if ( $_GET["page"] == 'wc-admin' ) {

			  wp_enqueue_script( 'testing-checkbox-custom-script', get_template_directory_uri() . '/assets/js/testing-checkbox-custom-script.js', array("jquery"), rand(111,9999), true );

		}

	}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * 
 12) Getting current page url on wp-admin/admin dashboard? && With Post Type [XYZ]
 *   + If we want to add CSS & JS in some fix page in admin dashboard then this condition will use
 */<?php

	if ( admin_url( 'edit.php?post_type=post' ) && ( 'XYZ' == get_post_type() ) ){

	}



/*
   13) Current screen object or null when screen not defined.
*      Useful later : #REF_URL : https://developer.wordpress.org/reference/functions/get_current_screen/
*/

#REF_URL : https://developer.wordpress.org/reference/functions/get_current_screen/


/*
14) Return current page type

#REF_URL https://wordpress.stackexchange.com/questions/83887/return-current-page-type

*/

function wpse8170_loop() {
    global $wp_query;
    $loop = 'notfound';

    if ( $wp_query->is_page ) {
        $loop = is_front_page() ? 'front' : 'page';
    } elseif ( $wp_query->is_home ) {
        $loop = 'home';
    } elseif ( $wp_query->is_single ) {
        $loop = ( $wp_query->is_attachment ) ? 'attachment' : 'single';
    } elseif ( $wp_query->is_category ) {
        $loop = 'category';
    } elseif ( $wp_query->is_tag ) {
        $loop = 'tag';
    } elseif ( $wp_query->is_tax ) {
        $loop = 'tax';
    } elseif ( $wp_query->is_archive ) {
        if ( $wp_query->is_day ) {
            $loop = 'day';
        } elseif ( $wp_query->is_month ) {
            $loop = 'month';
        } elseif ( $wp_query->is_year ) {
            $loop = 'year';
        } elseif ( $wp_query->is_author ) {
            $loop = 'author';
        } else {
            $loop = 'archive';
        }
    } elseif ( $wp_query->is_search ) {
        $loop = 'search';
    } elseif ( $wp_query->is_404 ) {
        $loop = 'notfound';
    }

    return $loop;
}

/**
 * 15) WooCommerce: Get Product Info (ID, SKU, $) From $product Object
 * 
 * #REF_URL = https://www.businessbloomer.com/woocommerce-easily-get-product-info-title-sku-desc-product-object/ 
*/


/**
 * 16) Global_Variables
 * 
 * #USEFUL_URL = #USEFUL_URL = [ https://codex.wordpress.org/Global_Variables ]
 * 
 * #REF_URL = https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/forEach#syntax
 * 
*/

/**
 * 17) JS CODE = Multiple Actions
 * 
*/	

	// 1) Condition 1 :

	//     => When user click on this [ Submit Button =>> [ id="doaction" ] ]
	
	// 2) Condition 2 :

	//     2.1 => After [Submit Button] Click ... Check Selected Value in select Options ... If this selected options value is [trash] :
	// 	2.1 => After [Submit Button] Click ... Check Minimum 1 [ONE] Checkbox is checked [ From All Checkbox : Min 1 is selected ]
	// 	       IF this checkbox check value is TRUE


	// 	In this Condition 2 [ Selected Option is TRASH && Also Checkbox any 1 is checked minimun ]
	// 	Then it will going on loop 

	// 3) Condition 3 :

	// 	=> In this Condition 2 [ Selected Option Value is (TRASH) && Also Checkbox any 1 is checked minimun ]

	// 	If( This Both Condition is TRUE )

	// 	3.1 [ SweetAlert Shown ]
	// 	3.2 [ SweetAlert Shown == YES [Button] ]
	// 	3.2 [ SweetAlert Shown == NO [Button] ]

	// 	3.1 = We will give sweetalert for user that user want to delete this post in question ?
	// 	3.2 = If user is click on yes => Means user confirm this action
	// 	3.2 = If user is click on yes => Means user cancel this action		

		// MAIN CODE */ ?>
			// <script type="text/javascript">

			// 	jQuery("#doaction").click(function( e ) {

			// 		e.preventDefault();

			// 		// console.log("Submit Button Click Event Happened");

			// 		var selected_checkbox_value = document.getElementById( 'bulk-action-selector-top' ).value;

			// 		let checkboxes = document.querySelector( 'input[name="post[]"]' );

			// 		if( selected_checkbox_value == 'trash' && ( checkboxes.checked == true ) ){
				
			// 				swal({

			// 					title: "Are you sure?",
			// 					text: 'It will temporary deleted in ' + selected_checkbox_value.toUpperCase(),
			// 					icon: "warning",
			// 					buttons: [
			// 					'No, cancel it!',
			// 					'Yes, I am sure!'
			// 					],
			// 					dangerMode: true,

			// 				}).then(function(isConfirm) {

			// 					if ( isConfirm ) {

			// 							var confirm_action = document.getElementById("posts-filter");

			// 							confirm_action.submit();

			// 							//console.log("Yes");

			// 								swal({
			// 								title: 'Trash!',
			// 								text: 'Post is temporary deleted successfully !',
			// 								icon: 'success'

			// 								});

			// 					}else {

			// 						window.location.reload();

			// 						// console.log("No");

			// 						swal({
			// 							title: 'Cancelled!',
			// 							text: 'Your post is safe !',
			// 							icon: 'error'

			// 						});

			// 					}

			// 				});

			// 		}

			// 	}); 

			// </script>

				// jQuery("#doaction").click(function( e ) {

				//     e.preventDefault();

				//     // console.log("Submit Button Click Event Happened");

				//     var selected_checkbox_value = document.getElementById( 'bulk-action-selector-top' ).value;

				//     let checkboxes = document.querySelector( 'input[name="post[]"]' );

				//     if( selected_checkbox_value == 'trash' && ( checkboxes.checked == true ) ){
				
				//             swal({

				//                 title: "Are you sure?",
				//                 text: 'It will temporary deleted in ' + selected_checkbox_value.toUpperCase(),
				//                 icon: "warning",
				//                 buttons: [
				//                 'No, cancel it!',
				//                 'Yes, I am sure!'
				//                 ],
				//                 dangerMode: true,

				//             }).then(function(isConfirm) {

				//                 if ( isConfirm ) {

				//                         var confirm_action = document.getElementById("posts-filter");

				//                         confirm_action.submit();

				//                         //console.log("Yes");

				//                             swal({
				//                               title: 'Trash!',
				//                               text: 'Post is temporary deleted successfully !',
				//                               icon: 'success'

				//                             });

				//                 }else {

				//                     window.location.reload();

				//                     // console.log("No");

				//                     swal({
				//                         title: 'Cancelled!',
				//                         text: 'Your post is safe !',
				//                         icon: 'error'

				//                     });

				//                 }

				//             });

				//     }

				// });<?php

		// MAIN CODE

		// [ PRACTICE CODE EXTRA START ]
		<?php

				// document.getElementById("posts-filter").addEventListener("submit", function(){

				//     //console.log("YEs In");


				//     document.querySelector('#bulk-action-selector-top').addEventListener('change', function() {
				    
				//         var form = this;

				//         let selectedvalue = this.value;

				//         if( selectedvalue == 'trash' ){
				      
				//                 swal({

				//                     title: "Are you sure?",
				//                     text: 'It will temporary deleted in ' + selectedvalue.toUpperCase(),
				//                     icon: "warning",
				//                     buttons: [
				//                     'No, cancel it!',
				//                     'Yes, I am sure!'
				//                     ],
				//                     dangerMode: true,

				//                 }).then(function(isConfirm) {

				//                     if ( isConfirm ) {

				//                         swal({
				//                           title: 'Trash!',
				//                           text: 'Post is temporary deleted successfully !',
				//                           icon: 'success'

				//                         });

				//                         var confirm_action = document.getElementById("posts-filter");

				//                         confirm_action.submit();

				//                     }else {

				//                         swal({
				//                             title: 'Cancelled!',
				//                             text: 'Your post is safe !',
				//                             icon: 'error'
				//                         });

				//                         window.location.reload();

				//                       }

				//                 });

				//         }

				//     });


				// });

			    // document.querySelector('#bulk-action-selector-top').addEventListener('change', function() {
			    
			    //     var form = this;

			    //     let selectedvalue = this.value;

			    //     if( selectedvalue == 'trash' ){
			      
			    //             swal({

			    //                 title: "Are you sure?",
			    //                 text: 'It will temporary deleted in ' + selectedvalue.toUpperCase(),
			    //                 icon: "warning",
			    //                 buttons: [
			    //                 'No, cancel it!',
			    //                 'Yes, I am sure!'
			    //                 ],
			    //                 dangerMode: true,

			    //             }).then(function(isConfirm) {

			    //                 if ( isConfirm ) {

			    //                     swal({
			    //                       title: 'Trash!',
			    //                       text: 'Post is temporary deleted successfully !',
			    //                       icon: 'success'

			    //                     });

			    //                     var confirm_action = document.getElementById("posts-filter");

			    //                     confirm_action.submit();

			    //                 }else {

			    //                     swal({
			    //                         title: 'Cancelled!',
			    //                         text: 'Your post is safe !',
			    //                         icon: 'error'
			    //                     });

			    //                     window.location.reload();

			    //                   }

			    //             });

			    //     }

			    // });


				// document.querySelector('#bulk-action-selector-top').addEventListener('change', function() {

				// console.log( "Hello all !" );




				//     var selected = new Array();

				//     $("#posts-filter input[type=checkbox]:checked").each(function () {
				//         selected.push(this.value);
				//     });




				    // var ele = document.getElementsByName('post[]');  

				    // for(var i=0; i<ele.length; i++){  
				        
				    //     if(ele[i].type=='checkbox')  
				            

				    //         ele[i].checked=true;  
				    

				    // }



				// n = jQuery("input:checked").length;



				 // if (jQuery(this).prop("checked") == true) {

				 //    console.log( "Value is Exists" );

				 // }else{

				 //    console.log( "Error ! Not Found" );

				 // }


				//console.log($('input[name="locationthemes"]:checked').serialize());



				        // jQuery(".price").change(function (i) {

				            // n = jQuery("input:checked").length;


				            // if (jQuery(this).prop("checked") == true) {

				            //     // jQuery(".price column-price").show();

				            //     alert( jQuery(".price column-price").value );

				            //     console.log( "Yes" );

				            // } else {
				            //     if (n == 0) {

				            //         jQuery(".price column-price").hide();

				            //         console.log( "No" );

				            //     }
				            // }


				        // });



				// });

		?>
		//<!-- [ PRACTICE CODE EXTRA START ] -->
	
	<?php
	
/**
 * 18)  
 * 
 * 	   If you want to flush rules while updating posts based on post type:
 *     REF_URL : https://developer.wordpress.org/reference/functions/flush_rewrite_rules/
 * 
*/	
	function wpdoc_flush_rules_on_save_posts( $post_id ) {

		// Check the correct post type.
		// Example to check, if the post type isn't 'post' then don't flush, just return.
		if ( ! empty( $_POST['post_type'] && $_POST['post_type'] != 'post' ) {
			return;
		}
	
		flush_rewrite_rules();
	
	}
	
	add_action( 'save_post', 'wpdoc_flush_rules_on_save_posts', 20, 2);


/**
 * 19)  
 * 
 * 	   PHP: How to compare WordPress versions?
 *     REF_URL : https://stackoverflow.com/questions/42506050/php-how-to-compare-wordpress-versions
 * 
*/	


/**
 * 20)  
 * 
 * 	   Add_action in class and use it in theme
 * 
 *     REF_URL : https://wordpress.stackexchange.com/questions/62979/add-action-in-class-and-use-it-in-theme
 * 
*/	
class My_Plugin
{
    private $var = 'foo';

    protected static $instance = NULL;

    public static function get_instance()
    {
        // create an object
        NULL === self::$instance and self::$instance = new self;

        return self::$instance; // return the object
    }

    public function __construct()
    {
        // set up your variables etc.
    }

    public function foo()
    {
        return $this->var;
    }
}

// create an instance on wp_loaded
add_action( 'wp_loaded', array( 'My_Plugin', 'get_instance' ) );


// 21) Calls the callback functions that have been added to an action hook.

#RFE_URL = https://developer.wordpress.org/reference/functions/do_action/


// The action callback function.
function example_callback( $arg1, $arg2 ) {
    // (maybe) do something with the args.
}
add_action( 'example_action', 'example_callback', 10, 2 );

/*
 * Trigger the actions by calling the 'example_callback()' function
 * that's hooked onto `example_action` above.
 *
 * - 'example_action' is the action hook.
 * - $arg1 and $arg2 are the additional arguments passed to the callback.
do_action( 'example_action', $arg1, $arg2 );



*** https://developer.wordpress.org/apis/security/ ****

1] https://developer.wordpress.org/apis/security/sanitizing/
2] https://developer.wordpress.org/apis/security/escaping/
3] https://developer.wordpress.org/apis/security/data-validation/

// 22) Escaping with Localization

#RFE_URL = https://developer.wordpress.org/apis/security/escaping/

https://developer.wordpress.org/apis/security/escaping/

esc_html_e( 'Hello World', 'text_domain' );
// Same as
echo esc_html( __( 'Hello World', 'text_domain' ) );


=============================================================================================================
esc_html() – Use anytime an HTML element encloses a section of data being displayed. This will remove HTML.

<h4><?php echo esc_html( $title ); ?></h4>


=============================================================================================================
esc_js() – Use for inline Javascript.


<div onclick='<?php echo esc_js( $value ); ?>' />
=============================================================================================================


esc_url() – Use on all URLs, including those in the src and href attributes of an HTML element.

<img alt="" src="<?php echo esc_url( $media_url ); ?>" />

=============================================================================================================


